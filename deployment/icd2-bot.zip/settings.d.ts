declare const settings: {
    bots: {
        port: string | number;
    };
};
export default settings;
