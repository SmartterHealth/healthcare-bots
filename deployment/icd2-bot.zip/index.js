"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const restify = require("restify");
const benefits_1 = require("./bots/benefits");
const icd2_1 = require("./bots/icd2");
const settings_1 = require("./settings");
// Create HTTP server.
const server = restify.createServer();
server.name = 'SmartterHealth Bot Server';
server.listen(settings_1.default.bots.port, () => {
    console.log(`${server.name} is listening on ${settings_1.default.bots.port}.`);
    if (process.env.NODE_ENV === 'DEVELOPMENT') {
        console.warn('Warning: NODE_ENV is DEVELOPMENT.');
    }
    // Fire the bots up!
    initializeBots();
    if (process.env.NODE_ENV === 'DEVELOPMENT') {
        console.log('Hit CTRL+C to quit.');
        console.log('Type rs+ENTER to restart.');
    }
});
/**
 * Initializes the bot class instances.
 */
const initializeBots = () => {
    try {
        const icd2 = new icd2_1.default(server);
        console.log('\t* ICD2 bot is up and running!');
    }
    catch (e) {
        const err = e;
        console.error(`ERROR: Could not start Icd2Bot: ${err}\n${err.stack}`);
    }
    try {
        const benefits = new benefits_1.default(server);
        console.log('\t* Benefits bot is up and running!');
    }
    catch (e) {
        const err = e;
        console.error(`ERROR: Could not start BenefitsBot: ${err}\n${err.stack}`);
    }
};
//# sourceMappingURL=index.js.map