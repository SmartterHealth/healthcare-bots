/**
 * Converts the value to a boolean.
 * @param value The value to convert.
 * @param defaultValue The default value if the value cannot be coerced to a boolean.
 */
export declare function convertToBoolean(value: string | undefined, defaultValue?: boolean): boolean;
/**
 * Converts the value to an integer.
 * @param value The value to convert.
 * @param defaultValue The default value if the value cannot be coerced to an integer.
 */
export declare function convertToInteger(value: string | undefined, defaultValue?: number): number;
