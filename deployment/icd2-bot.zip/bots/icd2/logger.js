"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const chalk = require("chalk");
const settings_1 = require("./settings");
/**
 * The prefix for messages logged to console. Pulls value from ENV and decorates
 * with colored brackets. Useful for distinguishing custom logs from the bot framework output.
 */
const prefix = chalk.default.white('[') + chalk.default.gray(settings_1.default.bot.displayName) + chalk.default.white(']');
/**
 * Simple message logging function.
 * @param message The message to log.
 */
function log(message) {
    if (typeof message === 'object') {
        message = JSON.stringify(message);
    }
    console.log(`${prefix} ${message}`);
}
exports.default = log;
//# sourceMappingURL=logger.js.map