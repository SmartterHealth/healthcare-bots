import { Attachment, TurnContext } from 'botbuilder';
export declare abstract class AdaptiveCardHelperBase {
    protected readonly card: any;
    args: string;
    context: TurnContext;
    headerDescription: string;
    headerTitle: string;
    readonly isMSTeams: boolean;
    static loadCardElementJSON(pathToTemplate: string): any;
    private _card;
    private _args;
    private _context;
    constructor(context: TurnContext);
    abstract render(): Attachment;
    protected createAction(options: ICardAction): ICardAction;
    protected submitAction(data: any, text?: string, displayText?: string): {
        type: string;
        text: string | undefined;
        data: any;
    };
}
export declare type CardActionTypeName = 'Action.Submit' | 'Action.OpenUrl';
export interface ICardAction {
    id?: string;
    title: string;
    actionType: CardActionType;
    type?: string;
    iconUrl?: string;
    data?: any;
    url?: string;
}
export declare enum CardActionType {
    OpenUrl = 0,
    Submit = 1
}
