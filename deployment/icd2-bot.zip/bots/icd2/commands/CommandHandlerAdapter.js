"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const CommandHandlerBase_1 = require("./CommandHandlerBase");
class CommandHandlerAdapter {
    constructor(commandTypes) {
        /** Private field that stores a list of all known command handler types. */
        this._commandTypes = [];
        this._possibleCommands = [];
        this._commandTextParser = '';
        /** Private field that stores a mapping of command text to the associated command handler. */
        this._commandMapping = {};
        this.initCommandTypes(commandTypes);
        /// ^(search\s*codes|get\s*code|help)\s*(.*)$/gim;
        this._commandTextParser = `^(${this._possibleCommands.join('|')})\s*(.*)$`;
    }
    async execute(context, commandText) {
        const re = new RegExp(this._commandTextParser, 'gim');
        const matches = re.exec(commandText);
        let cmd;
        let args;
        let commandAlias = '';
        if (!matches || matches.length < 3) {
            // We didn't find any commands that matches the commandText input, so use the default.
            // tslint:disable-next-line:no-string-literal
            cmd = this._commandMapping['default'];
            commandAlias = cmd.commands[0];
            args = '';
        }
        else {
            // We found a match, so grab the commandText and the arguments
            commandAlias = matches[1].trim();
            args = matches[2];
            cmd = this._commandMapping[commandAlias.toLowerCase().trim()];
        }
        // Execute the command.
        await cmd.execute(context, commandAlias.toLowerCase().trim(), (args).trim());
    }
    initCommandTypes(registrations) {
        this._commandTypes = registrations;
        // tslint:disable-next-line:prefer-for-of
        for (let i = 0; i < this._commandTypes.length; i++) {
            // Grab the command handler type from our registration list.
            const registration = this._commandTypes[i];
            // Grab command handler metadata
            const displayName = Reflect.getMetadata('displayName', registration);
            const isDefault = Reflect.getMetadata('isDefault', registration);
            const commands = Reflect.getMetadata('commands', registration);
            /** Create an instance of our command handler, and map each command text to that instance
            * This mapping will look something like this in memory:
            * -----------------------------------------
            * Command Text     Command Handler Instance
            * -----------------------------------------
            * search codes     SearchCodesBotCommand
            * sc               SearchCodesBotCommand
            * get codes        GetCodeBotCommand
            * gc               GetCodeBotCommand
            * help             HelpBotCommand
            * welcome          WelcomeBotCommand
             */
            const instance = (CommandHandlerBase_1.CommandHandlerBase.createInstance(registration));
            commands.map((command) => {
                this._commandMapping[command] = instance;
            });
            // Register the default command
            if (isDefault) {
                if (instance != null) {
                    // tslint:disable-next-line:no-string-literal
                    this._commandMapping['default'] = instance;
                }
            }
            this._possibleCommands = this._possibleCommands.concat(commands);
        }
    }
}
exports.CommandHandlerAdapter = CommandHandlerAdapter;
//# sourceMappingURL=CommandHandlerAdapter.js.map