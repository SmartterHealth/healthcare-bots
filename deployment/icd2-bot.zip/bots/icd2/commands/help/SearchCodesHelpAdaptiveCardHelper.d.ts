import { AdaptiveCardHelperBase } from '../AdaptiveCardHelperBase';
import { Attachment } from 'botbuilder';
export declare class SearchCodesHelpAdaptiveCardHelper extends AdaptiveCardHelperBase {
    render(): Attachment;
}
