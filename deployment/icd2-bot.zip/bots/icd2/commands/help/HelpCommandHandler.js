"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const CommandHandlerBase_1 = require("../CommandHandlerBase");
const HelpAdaptiveCardHelper_1 = require("./HelpAdaptiveCardHelper");
const settings_1 = require("../../settings");
const SearchCodesHelpAdaptiveCardHelper_1 = require("./SearchCodesHelpAdaptiveCardHelper");
const GetCodeHelpAdaptiveCardHelper_1 = require("./GetCodeHelpAdaptiveCardHelper");
const appInsights = require("applicationinsights");
/**
 * Simple flag that indicates whether this is the default command.
 */
const IS_DEFAULT = false;
let HelpCommandHandler = class HelpCommandHandler extends CommandHandlerBase_1.CommandHandlerBase {
    async execute(context, command, args) {
        let client = appInsights.defaultClient;
        args = (args === undefined || args === null) ? '' : args;
        const card = this.determineCardHelper(args, context);
        await context.sendActivity({
            attachments: [card.render()],
        });
        return { status: CommandHandlerBase_1.CommandStatus.Success, message: `Command ${this.displayName} executed successfully.` };
    }
    determineCardHelper(args, context) {
        let card;
        switch (args.toLowerCase()) {
            case 'search codes':
                card = new SearchCodesHelpAdaptiveCardHelper_1.SearchCodesHelpAdaptiveCardHelper(context);
                card.headerTitle = `${settings_1.default.bot.displayName} -> ${this.displayName} -> Search Codes`;
                card.headerDescription = `Searching for ICD10 codes by keyword is easy!`;
                break;
            case 'get code':
                card = new GetCodeHelpAdaptiveCardHelper_1.GetCodeHelpAdaptiveCardHelper(context);
                card.headerTitle = `${settings_1.default.bot.displayName} -> ${this.displayName} -> Get Code`;
                card.headerDescription = `Getting details for an ICD10 code is easy!`;
                break;
            default:
                card = new HelpAdaptiveCardHelper_1.HelpAdaptiveCardHelper(context);
                card.headerTitle = `${settings_1.default.bot.displayName} -> ${this.displayName}`;
                card.headerDescription = `Welcome to ICD2 Bot, ${context.activity.from.name}! This bot will assist you with ICD10 codes. Please select an option below. You can return to this screen at any time by typing **help**.`;
                break;
        }
        card.args = args;
        return card;
    }
};
__decorate([
    CommandHandlerBase_1.Traceable()
], HelpCommandHandler.prototype, "execute", null);
HelpCommandHandler = __decorate([
    CommandHandlerBase_1.Command('Help', ['help'], IS_DEFAULT)
], HelpCommandHandler);
exports.HelpCommandHandler = HelpCommandHandler;
//# sourceMappingURL=HelpCommandHandler.js.map