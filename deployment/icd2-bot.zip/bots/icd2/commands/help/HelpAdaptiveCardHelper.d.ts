import { AdaptiveCardHelperBase } from '../AdaptiveCardHelperBase';
import { Attachment } from 'botbuilder';
export declare class HelpAdaptiveCardHelper extends AdaptiveCardHelperBase {
    render(): Attachment;
}
