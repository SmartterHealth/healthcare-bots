"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const AdaptiveCardHelperBase_1 = require("../AdaptiveCardHelperBase");
const botbuilder_1 = require("botbuilder");
class HelpAdaptiveCardHelper extends AdaptiveCardHelperBase_1.AdaptiveCardHelperBase {
    render() {
        this.card.actions = [];
        this.card.actions.push(this.createAction({ title: 'Search Codes by Keyword(s)', actionType: AdaptiveCardHelperBase_1.CardActionType.Submit, data: 'help search codes' }));
        this.card.actions.push(this.createAction({ title: 'Get Code Details', actionType: AdaptiveCardHelperBase_1.CardActionType.Submit, data: 'help get code' }));
        return botbuilder_1.CardFactory.adaptiveCard(this.card);
    }
}
exports.HelpAdaptiveCardHelper = HelpAdaptiveCardHelper;
//# sourceMappingURL=HelpAdaptiveCardHelper.js.map