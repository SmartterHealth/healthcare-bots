import { TurnContext } from 'botbuilder';
import { CommandHandlerBase, ICommandResults } from '../CommandHandlerBase';
export declare class HelpCommandHandler extends CommandHandlerBase {
    execute(context: TurnContext, command: string, args: string): Promise<ICommandResults>;
    private determineCardHelper;
}
