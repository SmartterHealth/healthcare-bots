import { AdaptiveCardHelperBase } from '../AdaptiveCardHelperBase';
import { Attachment } from 'botbuilder';
export declare class GetCodeHelpAdaptiveCardHelper extends AdaptiveCardHelperBase {
    render(): Attachment;
}
