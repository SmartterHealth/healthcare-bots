"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const AdaptiveCardHelperBase_1 = require("../AdaptiveCardHelperBase");
const botbuilder_1 = require("botbuilder");
const path = require("path");
class SearchCodesHelpAdaptiveCardHelper extends AdaptiveCardHelperBase_1.AdaptiveCardHelperBase {
    render() {
        let template = AdaptiveCardHelperBase_1.AdaptiveCardHelperBase.loadCardElementJSON(path.join(__dirname, './SearchCodesHelpAdaptiveCardHelper.json'));
        this.card.body.push(template);
        this.card.actions = [];
        this.card.actions.push(this.createAction({ title: 'Try it now!', actionType: AdaptiveCardHelperBase_1.CardActionType.Submit, data: 'search codes edema orbit' }));
        return botbuilder_1.CardFactory.adaptiveCard(this.card);
    }
}
exports.SearchCodesHelpAdaptiveCardHelper = SearchCodesHelpAdaptiveCardHelper;
//# sourceMappingURL=SearchCodesHelpAdaptiveCardHelper.js.map