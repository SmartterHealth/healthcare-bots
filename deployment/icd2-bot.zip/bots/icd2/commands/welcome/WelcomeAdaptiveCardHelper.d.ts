import { AdaptiveCardHelperBase } from '../AdaptiveCardHelperBase';
import { Attachment } from 'botbuilder';
export declare class WelcomeAdaptiveCardHelper extends AdaptiveCardHelperBase {
    render(): Attachment;
}
