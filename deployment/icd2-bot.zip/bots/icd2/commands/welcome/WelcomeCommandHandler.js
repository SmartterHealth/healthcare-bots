"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const CommandHandlerBase_1 = require("../CommandHandlerBase");
const WelcomeAdaptiveCardHelper_1 = require("./WelcomeAdaptiveCardHelper");
const settings_1 = require("../../settings");
/**
 * Simple flag that indicates whether this is the default command.
 */
const IS_DEFAULT = true;
/**
 *
 */
let WelcomeCommandHandler = class WelcomeCommandHandler extends CommandHandlerBase_1.CommandHandlerBase {
    /**
     *
     * @param context A TurnContext instance containing all the data needed for processing this conversation turn.
     * @param args The arguments sent to the command.
     */
    async execute(context, command, args) {
        let card = new WelcomeAdaptiveCardHelper_1.WelcomeAdaptiveCardHelper(context);
        card.headerTitle = settings_1.default.bot.displayName;
        card.headerDescription = `Welcome, ${context.activity.from.name}! Enter a command or type *'help'* to begin.`;
        await context.sendActivity({
            attachments: [card.render()],
        });
        return { status: CommandHandlerBase_1.CommandStatus.Success, message: `Command ${this.displayName} executed successfully.` };
    }
};
__decorate([
    CommandHandlerBase_1.Traceable()
], WelcomeCommandHandler.prototype, "execute", null);
WelcomeCommandHandler = __decorate([
    CommandHandlerBase_1.Command('Welcome', ['w', 'welcome'], IS_DEFAULT)
], WelcomeCommandHandler);
exports.WelcomeCommandHandler = WelcomeCommandHandler;
//# sourceMappingURL=WelcomeCommandHandler.js.map