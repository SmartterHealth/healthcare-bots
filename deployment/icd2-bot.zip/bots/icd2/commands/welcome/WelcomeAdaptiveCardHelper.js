"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const AdaptiveCardHelperBase_1 = require("../AdaptiveCardHelperBase");
const botbuilder_1 = require("botbuilder");
class WelcomeAdaptiveCardHelper extends AdaptiveCardHelperBase_1.AdaptiveCardHelperBase {
    render() {
        return botbuilder_1.CardFactory.adaptiveCard(this.card);
    }
}
exports.WelcomeAdaptiveCardHelper = WelcomeAdaptiveCardHelper;
//# sourceMappingURL=WelcomeAdaptiveCardHelper.js.map