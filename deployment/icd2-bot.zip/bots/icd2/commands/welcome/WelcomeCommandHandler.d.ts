import { TurnContext } from 'botbuilder';
import { CommandHandlerBase, ICommandResults } from '../CommandHandlerBase';
/**
 *
 */
export declare class WelcomeCommandHandler extends CommandHandlerBase {
    /**
     *
     * @param context A TurnContext instance containing all the data needed for processing this conversation turn.
     * @param args The arguments sent to the command.
     */
    execute(context: TurnContext, command: string, args: string): Promise<ICommandResults>;
}
