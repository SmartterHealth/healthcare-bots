"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const sql = require("mssql");
require("reflect-metadata");
const settings_1 = require("../../settings");
const CommandHandlerBase_1 = require("../CommandHandlerBase");
const GetCodeAdaptiveCardHelper_1 = require("./GetCodeAdaptiveCardHelper");
/**
 * Simple flag that indicates whether this is the default command.
 */
const IS_DEFAULT = false;
let GetCodeCommandHandler = class GetCodeCommandHandler extends CommandHandlerBase_1.CommandHandlerBase {
    async execute(context, command, args) {
        args = (args === undefined || args === null) ? '' : args;
        args = args.trim();
        let code = null;
        let cmdStatus = CommandHandlerBase_1.CommandStatus.Success;
        let cmdStatusText;
        try {
            code = await getCode(args);
            if (code) {
                cmdStatusText = `ICD10 code **'${args}'** found!`;
            }
            else {
                cmdStatusText = `A code for **'${args}'** was not found. Please try again.`;
                cmdStatus = CommandHandlerBase_1.CommandStatus.FailNoError;
            }
        }
        catch (err) {
            cmdStatus = CommandHandlerBase_1.CommandStatus.Error;
            cmdStatusText = err.toString();
        }
        const card = new GetCodeAdaptiveCardHelper_1.GetCodeAdaptiveCardHelper(context);
        card.args = args;
        card.headerTitle = `${settings_1.default.bot.displayName} -> ${this.displayName} -> ${args}`;
        card.headerDescription = (cmdStatus == CommandHandlerBase_1.CommandStatus.Error) ? `An error has occured. Please contact your administrator.` : cmdStatusText;
        card.dataSource = code;
        await context.sendActivity({
            attachments: [card.render()],
        });
        return { status: (cmdStatus), message: cmdStatusText };
    }
};
__decorate([
    CommandHandlerBase_1.Traceable()
], GetCodeCommandHandler.prototype, "execute", null);
GetCodeCommandHandler = __decorate([
    CommandHandlerBase_1.Command('Get Code', ['gc', 'get code', 'code'], IS_DEFAULT)
], GetCodeCommandHandler);
exports.GetCodeCommandHandler = GetCodeCommandHandler;
async function getCode(code) {
    const codes = [];
    let result = null;
    const pool = await sql.connect(settings_1.default.db);
    try {
        const dbresults = await pool.request()
            .input('code', sql.VarChar(150), code)
            .execute('GET_CODE');
        if (dbresults.recordset.length > 0) {
            result = dbresults.recordset[0];
        }
    }
    finally {
        sql.close();
    }
    return result;
}
//# sourceMappingURL=GetCodeCommandHandler.js.map