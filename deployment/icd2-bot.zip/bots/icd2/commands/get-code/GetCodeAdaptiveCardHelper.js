"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const AdaptiveCardHelperBase_1 = require("../AdaptiveCardHelperBase");
const botbuilder_1 = require("botbuilder");
const path = require("path");
class GetCodeAdaptiveCardHelper extends AdaptiveCardHelperBase_1.AdaptiveCardHelperBase {
    get dataSource() {
        return this._dataSource;
    }
    set dataSource(value) {
        this._dataSource = value;
    }
    render() {
        this.renderCore();
        this.renderBingSearch();
        return botbuilder_1.CardFactory.adaptiveCard(this.card);
    }
    /**
     * Renders the main part of the adaptive card.
     */
    renderCore() {
        if (this.dataSource != null) {
            // Load the JSON template, and set code, description, and chapter.
            let template = AdaptiveCardHelperBase_1.AdaptiveCardHelperBase.loadCardElementJSON(path.join(__dirname, './GetCodeAdaptiveCardHelper.json'));
            template.items[0].columns[1].items[0].text = this.dataSource.code;
            template.items[1].columns[1].items[0].text = this.dataSource.description;
            template.items[2].columns[1].items[0].text = this.dataSource.chapter;
            template.items[3].columns[1].items[0].text = (this.dataSource.hipaa) ? 'yes' : 'no';
            // Append to the card's body.
            this.card.body.push(template);
        }
    }
    /**
     * Renders the Bing Search button, which will execute a Bing query for the specified ICD10 code.
     */
    renderBingSearch() {
        if (this.dataSource != null) {
            // Create the action button.
            const bingSearchAction = this.createAction({
                title: 'Open in Bing Search',
                url: `https://www.bing.com/search?q=icd10 code ${this.dataSource.code}`,
                actionType: AdaptiveCardHelperBase_1.CardActionType.OpenUrl,
                iconUrl: 'https://i.imgur.com/oV6TgTL.png'
            });
            // Create the actions array and and the action button.
            this.card.actions = [];
            this.card.actions.push(bingSearchAction);
        }
    }
}
exports.GetCodeAdaptiveCardHelper = GetCodeAdaptiveCardHelper;
//# sourceMappingURL=GetCodeAdaptiveCardHelper.js.map