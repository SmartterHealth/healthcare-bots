import { AdaptiveCardHelperBase } from '../AdaptiveCardHelperBase';
import { IICD10Code } from '../IICD10Code';
import { Attachment } from 'botbuilder';
export declare class GetCodeAdaptiveCardHelper extends AdaptiveCardHelperBase {
    private _dataSource;
    dataSource: IICD10Code | null;
    render(): Attachment;
    /**
     * Renders the main part of the adaptive card.
     */
    private renderCore;
    /**
     * Renders the Bing Search button, which will execute a Bing query for the specified ICD10 code.
     */
    private renderBingSearch;
}
