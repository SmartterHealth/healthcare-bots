"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const logger_1 = require("../logger");
const settings_1 = require("../settings");
const appInsights = require("applicationinsights");
function Traceable(prefix = 'ICD2 Command') {
    return function (target, propertyKey, descriptor) {
        let originalMethod = descriptor.value;
        // Wrapping the original method
        descriptor.value = async function (...args) {
            let result = null;
            let context = args[0];
            try {
                // Simple trace
                logger_1.default(`Invoked ${prefix} '${target.displayName}' with the following arguments '${args[2]}'`);
                result = await originalMethod.apply(this, args);
            }
            finally {
                if (result != null) {
                    logger_1.default(`Invoked ${prefix} '${target.displayName}' with the following results '${result.message}'`);
                    // Custom event tracking in Azure AppInsights.
                    if (settings_1.default.appInsights.disabled == false) {
                        let client = appInsights.defaultClient;
                        client.trackEvent({
                            'name': prefix,
                            properties: {
                                commandText: '' + args[1],
                                commandName: target.displayName,
                                commandStatus: '' + result.status,
                                commandStatusText: result.message,
                                channelId: context.activity.channelId,
                                args: '' + args[2]
                            }
                        });
                    }
                }
                return result;
            }
        };
    };
}
exports.Traceable = Traceable;
/**
 * Class decorator that exposes command metadata to the BotCommandAdapter.
 * @param displayName The friendly name for the command.
 * @param commands A list of aliases for the command.
 * @param isDefault A flag that indicates whether the command is the default command.
 */
function Command(displayName, commands, isDefault = false) {
    // tslint:disable-next-line:ban-types
    return (target) => {
        // Add class metadata. For more information on TypeScript decorators, please see https://aka.ms/tsdecorators.
        Reflect.defineMetadata('displayName', displayName, target);
        Reflect.defineMetadata('commands', commands, target);
        Reflect.defineMetadata('isDefault', isDefault, target);
    };
}
exports.Command = Command;
/**
 * Base class that implements shared command handler properties and behavior.
 */
class CommandHandlerBase {
    /** Gets the friendly name for the command. */
    get displayName() {
        if (this._displayName === undefined) {
            this._displayName = Reflect.getMetadata('displayName', this.constructor);
        }
        return this._displayName;
    }
    /** Gets a list of aliases for the command. */
    get commands() {
        if (this._commands === undefined) {
            this._commands = Reflect.getMetadata('commands', this.constructor);
        }
        return this._commands;
    }
    /** Gets a flag that indicates whether the command is the default command. */
    get isDefault() {
        if (this._isDefault === undefined) {
            this._isDefault = Reflect.getMetadata('isDefault', this.constructor);
        }
        return this._isDefault;
    }
    /**
     * Factory method that creates a new command based on the type argument.
     * @param type The type of command to create.
     */
    static createInstance(type) {
        const instance = Object.create(type.prototype);
        return instance;
    }
}
exports.CommandHandlerBase = CommandHandlerBase;
var CommandStatus;
(function (CommandStatus) {
    CommandStatus[CommandStatus["Success"] = 0] = "Success";
    CommandStatus[CommandStatus["FailNoError"] = 1] = "FailNoError";
    CommandStatus[CommandStatus["Error"] = 2] = "Error";
})(CommandStatus = exports.CommandStatus || (exports.CommandStatus = {}));
//# sourceMappingURL=CommandHandlerBase.js.map