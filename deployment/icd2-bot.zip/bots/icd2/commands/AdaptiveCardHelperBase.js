"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const botbuilder_1 = require("botbuilder");
const path = require("path");
const assert_1 = require("../assert");
class AdaptiveCardHelperBase {
    get card() {
        return this._card;
    }
    get args() {
        return this._args;
    }
    set args(value) {
        this._args = value;
    }
    get context() {
        return this._context;
    }
    set context(v) {
        this._context = v;
    }
    get headerDescription() {
        return this.card.body[1].items[0].text.text;
    }
    set headerDescription(v) {
        this.card.body[1].items[0].text = v;
    }
    get headerTitle() {
        return this.card.body[0].items[0].columns[1].items[0].text;
    }
    set headerTitle(v) {
        this.card.body[0].items[0].columns[1].items[0].text = v;
    }
    get isMSTeams() {
        return (this.context != null && this.context.activity.channelId != null && this.context.activity.channelId !== undefined && this.context.activity.channelId === 'msteams');
    }
    static loadCardElementJSON(pathToTemplate) {
        const template = (require(pathToTemplate));
        return JSON.parse(JSON.stringify(template));
    }
    constructor(context) {
        assert_1.Assert.isNotNull(context, botbuilder_1.TurnContext);
        this._context = context;
        this._card = AdaptiveCardHelperBase.loadCardElementJSON(path.join(__dirname, './AdaptiveCardTemplate.json'));
    }
    createAction(options) {
        const action = Object.assign({}, options);
        action.type = `Action.${CardActionType[options.actionType]}`;
        if (this.isMSTeams === true) {
            action.data = {
                msteams: {
                    type: 'messageBack',
                    text: options.data,
                    displayText: options.data,
                    value: options.data,
                },
            };
        }
        return action;
    }
    submitAction(data, text, displayText) {
        const action = {
            type: 'Action.Submit',
            text,
            data,
        };
        if (this.isMSTeams === true) {
            action.data = {
                msteams: {
                    type: 'messageBack',
                    text,
                    displayText,
                    value: data,
                },
            };
        }
        return action;
    }
}
exports.AdaptiveCardHelperBase = AdaptiveCardHelperBase;
var CardActionType;
(function (CardActionType) {
    CardActionType[CardActionType["OpenUrl"] = 0] = "OpenUrl";
    CardActionType[CardActionType["Submit"] = 1] = "Submit";
})(CardActionType = exports.CardActionType || (exports.CardActionType = {}));
//# sourceMappingURL=AdaptiveCardHelperBase.js.map