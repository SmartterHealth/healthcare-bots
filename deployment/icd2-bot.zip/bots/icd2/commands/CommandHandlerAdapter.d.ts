import { TurnContext } from 'botbuilder';
import 'reflect-metadata';
import { CommandHandlerBase } from './CommandHandlerBase';
export declare class CommandHandlerAdapter {
    /** Private field that stores a list of all known command handler types. */
    private _commandTypes;
    private _possibleCommands;
    private _commandTextParser;
    /** Private field that stores a mapping of command text to the associated command handler. */
    private _commandMapping;
    constructor(commandTypes: Array<typeof CommandHandlerBase>);
    execute(context: TurnContext, commandText: string): Promise<void>;
    private initCommandTypes;
}
