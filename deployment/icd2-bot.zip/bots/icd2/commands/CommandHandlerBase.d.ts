import { TurnContext } from 'botbuilder';
import 'reflect-metadata';
export declare function Traceable(prefix?: string): MethodDecorator;
/**
 * Class decorator that exposes command metadata to the BotCommandAdapter.
 * @param displayName The friendly name for the command.
 * @param commands A list of aliases for the command.
 * @param isDefault A flag that indicates whether the command is the default command.
 */
export declare function Command(displayName: string, commands: string[], isDefault?: boolean): ClassDecorator;
/**
 * Base class that implements shared command handler properties and behavior.
 */
export declare abstract class CommandHandlerBase {
    /** Gets the friendly name for the command. */
    readonly displayName: string;
    /** Gets a list of aliases for the command. */
    readonly commands: string[];
    /** Gets a flag that indicates whether the command is the default command. */
    readonly isDefault: boolean;
    /**
     * Factory method that creates a new command based on the type argument.
     * @param type The type of command to create.
     */
    static createInstance(type: typeof CommandHandlerBase): CommandHandlerBase;
    /** Private field that stores the friendly name for the command.  */
    private _displayName;
    /** Private field that stores a list of aliases for the command. */
    private _commands;
    /** Private field that stores a flag that indicates whether the command is the default command. */
    private _isDefault;
    /**
     * Executes the command.
     * @param context A TurnContext instance containing all the data needed for processing this conversation turn.
     * @param args The arguments send to the command.
     */
    abstract execute(context: TurnContext, command: string, args: string): Promise<ICommandResults>;
}
export declare enum CommandStatus {
    Success = 0,
    FailNoError = 1,
    Error = 2
}
export interface ICommandResults {
    status: CommandStatus;
    message: string;
    error?: Error;
}
