import { Attachment } from 'botbuilder';
import { IICD10SearchResults } from '../IICD10Code';
import { AdaptiveCardHelperBase } from '../AdaptiveCardHelperBase';
export declare class SearchCodesAdaptiveCardHelper extends AdaptiveCardHelperBase {
    private _dataSource;
    constructor(context: any);
    dataSource: IICD10SearchResults | null;
    render(): Attachment;
    private renderSearchResults;
}
