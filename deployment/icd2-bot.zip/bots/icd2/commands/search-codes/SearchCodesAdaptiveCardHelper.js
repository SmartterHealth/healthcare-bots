"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const botbuilder_1 = require("botbuilder");
const AdaptiveCardHelperBase_1 = require("../AdaptiveCardHelperBase");
const path = require("path");
class SearchCodesAdaptiveCardHelper extends AdaptiveCardHelperBase_1.AdaptiveCardHelperBase {
    constructor(context) {
        super(context);
        let template = SearchCodesAdaptiveCardHelper.loadCardElementJSON(path.join(__dirname, './SearchCodesAdaptiveCardHelper.json'));
    }
    get dataSource() {
        return this._dataSource;
    }
    set dataSource(searchResults) {
        this._dataSource = searchResults;
    }
    render() {
        this.renderSearchResults();
        return botbuilder_1.CardFactory.adaptiveCard(this.card);
    }
    renderSearchResults() {
        if (this.dataSource != null) {
            this.dataSource.codes.map((result) => {
                const template = SearchCodesAdaptiveCardHelper.loadCardElementJSON(path.join(__dirname, './SearchCodesAdaptiveCardHelper.json'));
                const root = template.items[0];
                root.columns[0].items[0].text = result.code;
                root.columns[1].items[0].text = result.description;
                root.selectAction = this.createAction({ title: result.code, actionType: AdaptiveCardHelperBase_1.CardActionType.Submit, data: `get code ${result.code}` });
                this.card.body.push(template);
            });
        }
    }
}
exports.SearchCodesAdaptiveCardHelper = SearchCodesAdaptiveCardHelper;
//# sourceMappingURL=SearchCodesAdaptiveCardHelper.js.map