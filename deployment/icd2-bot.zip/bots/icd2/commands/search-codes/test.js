"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const SearchCodesAdaptiveCardHelper_1 = require("./SearchCodesAdaptiveCardHelper");
const card = new SearchCodesAdaptiveCardHelper_1.SearchCodesAdaptiveCardHelper(null);
//# sourceMappingURL=test.js.map