import { TurnContext } from 'botbuilder';
import 'reflect-metadata';
import { CommandHandlerBase, ICommandResults } from '../CommandHandlerBase';
export declare class SearchCodesCommandHandler extends CommandHandlerBase {
    execute(context: TurnContext, command: string, args: string): Promise<ICommandResults>;
}
