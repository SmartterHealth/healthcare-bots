"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const sql = require("mssql");
require("reflect-metadata");
const assert_1 = require("../../assert");
const logger_1 = require("../../logger");
const settings_1 = require("../../settings");
const CommandHandlerBase_1 = require("../CommandHandlerBase");
const SearchCodesAdaptiveCardHelper_1 = require("./SearchCodesAdaptiveCardHelper");
/**
 * Simple flag that indicates whether this is the default command.
 */
const IS_DEFAULT = false;
let SearchCodesCommandHandler = class SearchCodesCommandHandler extends CommandHandlerBase_1.CommandHandlerBase {
    async execute(context, command, args) {
        args = (args === undefined || args === null) ? '' : args;
        args = args.trim();
        let results = null;
        let cmdStatus = CommandHandlerBase_1.CommandStatus.Success;
        let cmdStatusText;
        try {
            const query = parseKeywords(args);
            logger_1.default(`Searching for codes using query '${query}'`);
            results = await searchCodes(query);
            logger_1.default(`${results.codes.length} results returned for query '${query}'`);
            if (results.codes.length > 0) {
                // We got matches!
                cmdStatus = CommandHandlerBase_1.CommandStatus.Success;
                cmdStatusText = `Your search for **'${args}'** returned **${results.codes.length}** results. Click on a result for more details.`;
            }
            else {
                // No matches... :-/
                cmdStatus = CommandHandlerBase_1.CommandStatus.FailNoError;
                cmdStatusText = `Your search for **'${args}'** returned **${results.codes.length}** results. Please try again.`;
            }
        }
        catch (err) {
            console.log(err);
            cmdStatus = CommandHandlerBase_1.CommandStatus.Error;
            cmdStatusText = err.toString();
        }
        const card = new SearchCodesAdaptiveCardHelper_1.SearchCodesAdaptiveCardHelper(context);
        card.args = args;
        card.headerTitle = `${settings_1.default.bot.displayName} -> ${this.displayName} -> ${args}`;
        // Hide error messages with generic message.
        card.headerDescription = (cmdStatus === CommandHandlerBase_1.CommandStatus.Error) ? `An error has occured. Please contact your administrator.` : cmdStatusText;
        card.dataSource = results;
        // await context.sendActivity('Test');
        await context.sendActivity({
            attachments: [card.render()],
        });
        return { status: cmdStatus, message: cmdStatusText };
    }
};
__decorate([
    CommandHandlerBase_1.Traceable()
], SearchCodesCommandHandler.prototype, "execute", null);
SearchCodesCommandHandler = __decorate([
    CommandHandlerBase_1.Command('Search Codes', ['search codes', 'sc', 'search code'], IS_DEFAULT)
], SearchCodesCommandHandler);
exports.SearchCodesCommandHandler = SearchCodesCommandHandler;
/**
 * Parses the keywords into a SQL fulltext WHERE clause.
 * @param keywords The keywords to parse. Each keyword is joined by the SQL 'AND' operator. Phrases are identified by quotes.
 */
function parseKeywords(keywords) {
    assert_1.Assert.isNotNull(keywords, String);
    const regex = /("(.*)")|[^\W\d]+[\u00C0-\u017Fa-zA-Z'](\w|[-'](?=\w))*("(.*)")|[^\W\d]+[\u00C0-\u017Fa-zA-Z'](\w|[-'](?=\w))*/gi;
    const tokens = keywords.match(regex);
    if (tokens != null) {
        return tokens.join(' AND ');
    }
    return '';
}
/**
 * Calls the stored procedure that searches for ICD10 codes.
 * @param query The SQL fulltext WHERE clause.
 */
async function searchCodes(query) {
    assert_1.Assert.isNotNull(query, String);
    const codes = [];
    const results = { codes: (codes) };
    const pool = await sql.connect(settings_1.default.db);
    try {
        const dbresults = await pool.request()
            .input('keywords', sql.VarChar(150), query)
            .input('maxrows', sql.Int, settings_1.default.searchCodes.maxRows)
            .execute('SEARCH_CODES');
        results.codes = dbresults.recordset;
    }
    finally {
        sql.close();
    }
    return results;
}
//# sourceMappingURL=SearchCodesCommandHandler.js.map