/** Simple assertion library. */
export declare class Assert {
    /** Asserts that the value is NOT null. Can be overloaded to include type information. */
    static isNotNull<T>(value: T, x?: T & any): void;
    static isNotNullOrBlank<T>(value: T, name?: string): void;
}
