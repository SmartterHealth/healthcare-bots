"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/** Simple assertion library. */
class Assert {
    /** Asserts that the value is NOT null. Can be overloaded to include type information. */
    static isNotNull(value, x) {
        if (x === undefined) {
            x = { name: 'any' };
        }
        if (value === null || value === undefined) {
            throw new Error(`Argument of type '${x.name}' cannot be null!`);
        }
    }
    static isNotNullOrBlank(value, name) {
        if (value === null || value === undefined) {
            throw new Error(`Value '${name}' cannot be null!`);
        }
        if (typeof value === 'string') {
            if ((value + '').trim().length === 0) {
                throw new Error(`Value '${name}' cannot be null!`);
            }
        }
    }
}
exports.Assert = Assert;
//# sourceMappingURL=assert.js.map