"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Converts the value to a boolean.
 * @param value The value to convert.
 * @param defaultValue The default value if the value cannot be coerced to a boolean.
 */
function convertToBoolean(value, defaultValue = false) {
    return (value !== undefined && value !== null && (value.toLowerCase() === 'true' || value == '1'));
}
exports.convertToBoolean = convertToBoolean;
/**
 * Converts the value to an integer.
 * @param value The value to convert.
 * @param defaultValue The default value if the value cannot be coerced to an integer.
 */
function convertToInteger(value, defaultValue = 0) {
    let newValue = defaultValue;
    if (value !== undefined && value !== null) {
        try {
            // tslint:disable-next-line:radix
            newValue = parseInt('' + value);
        }
        catch (err) {
            newValue = defaultValue;
        }
    }
    return newValue;
}
exports.convertToInteger = convertToInteger;
//# sourceMappingURL=util.js.map