/**
 * Simple message logging function.
 * @param message The message to log.
 */
export default function log(message: string | object): void;
