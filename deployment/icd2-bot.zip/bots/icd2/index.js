"use strict";
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
Object.defineProperty(exports, "__esModule", { value: true });
// Import required bot services.
// See https://aka.ms/bot-services to learn more about the different parts of a bot.
const appInsights = require("applicationinsights");
const botbuilder_1 = require("botbuilder");
const CommandHandlerAdapter_1 = require("./commands/CommandHandlerAdapter");
const GetCodeCommandHandler_1 = require("./commands/get-code/GetCodeCommandHandler");
const HelpCommandHandler_1 = require("./commands/help/HelpCommandHandler");
const SearchCodesCommandHandler_1 = require("./commands/search-codes/SearchCodesCommandHandler");
const logger_1 = require("./logger");
const settings_1 = require("./settings");
// import { log } from './logger';
const WelcomeCommandHandler_1 = require("./commands/welcome/WelcomeCommandHandler");
appInsights.setup(settings_1.default.appInsights.instrumentationKey)
    .setAutoDependencyCorrelation(true)
    .setAutoCollectRequests(true)
    .setAutoCollectPerformance(true)
    .setAutoCollectExceptions(true)
    .setAutoCollectDependencies(true)
    .setAutoCollectConsole(true)
    .setUseDiskRetryCaching(true)
    .start();
// Create command adapter instance and register known command handlers.
const botCommandAdapter = new CommandHandlerAdapter_1.CommandHandlerAdapter([
    SearchCodesCommandHandler_1.SearchCodesCommandHandler,
    GetCodeCommandHandler_1.GetCodeCommandHandler,
    HelpCommandHandler_1.HelpCommandHandler,
    WelcomeCommandHandler_1.WelcomeCommandHandler,
]);
class Icd2Bot extends botbuilder_1.ActivityHandler {
    constructor(server) {
        super();
        this.adapter = new botbuilder_1.BotFrameworkAdapter({
            appId: settings_1.default.bot.MicrosoftAppId,
            appPassword: settings_1.default.bot.MicrosoftAppPassword,
        });
        server.post('/api/icd2/messages', (req, res) => {
            this.adapter.processActivity(req, res, async (context) => {
                // Route to main dialog.
                await this.run(context);
            });
        });
        // Catch-all for errors.
        this.adapter.onTurnError = async (context, error) => {
            // This check writes out errors to console log .vs. app insights.
            console.error(`\n [onTurnError]: ${error}`);
            // Send a message to the user
            await context.sendActivity(`Oops. Something went wrong!`);
        };
        // See https://aka.ms/about-bot-activity-message to learn more about the message and other activity types.
        this.onMessage(async (context, next) => {
            try {
                let commandText = context.activity.text;
                // MS Teams sends SubmitActions differently then other chat clients :-/
                if ((!commandText) && context.activity.value && context.activity.value.msteams) {
                    commandText = context.activity.value.msteams.text;
                }
                this.setUserId(context);
                // Execute the command via the command adapter, which will dispatch to the appropriate command handler.
                console.time('botCommandAdapter.execute');
                await botCommandAdapter.execute(context, commandText.trim());
            }
            catch (e) {
                const err = e;
                console.error(err);
            }
            finally {
                // By calling next() you ensure that the next BotHandler is run.
                console.timeEnd('botCommandAdapter.execute');
                await next();
            }
        });
        this.onMembersAdded(async (context, next) => {
            const membersAdded = context.activity.membersAdded;
            if (membersAdded != null) {
                for (const member of membersAdded) {
                    if (member.id !== context.activity.recipient.id) {
                        logger_1.default(`User ${context.activity.from.name} added to chat session.`);
                        this.setUserId(context);
                        await botCommandAdapter.execute(context, '');
                    }
                }
            }
            // By calling next() you ensure that the next BotHandler is run.
            await next();
        });
    }
    /** Sets the user ID for the current user. */
    setUserId(context) {
        appInsights.defaultClient.context.tags[appInsights.defaultClient.context.keys.userAuthUserId] = context.activity.from.id;
        appInsights.defaultClient.context.tags[appInsights.defaultClient.context.keys.userAccountId] = context.activity.from.id;
        appInsights.defaultClient.context.tags[appInsights.defaultClient.context.keys.userId] = context.activity.from.name;
    }
}
exports.default = Icd2Bot;
//# sourceMappingURL=index.js.map