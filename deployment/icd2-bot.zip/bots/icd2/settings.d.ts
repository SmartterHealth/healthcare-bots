/**
 * IMPORTANT: Ensure that bot settings have unique prefix!
 */
declare const settings: {
    bot: {
        displayName: string;
        /** The ID of the bot registered in Azure. */
        MicrosoftAppId: string | undefined;
        /** The password/secret of the bot registered in Azure. */
        MicrosoftAppPassword: string | undefined;
    };
    /** Exposes Azure Application Insights settings from ENV. */
    appInsights: {
        /** The Azure Insights nstumentation key. You can get this value from your App Insights instance in the Azure Portal. */
        instrumentationKey: string | undefined;
        /** Disables Azure App Insights. Specify a 1 (disabled) or 0 (enabled) in your ENV file or Azure App Service configuration. */
        disabled: boolean;
    };
    /** Exposes code search settings from ENV. */
    searchCodes: {
        /** The maximum number of rows to return for an ICD10 code search. */
        maxRows: number;
    };
    /** Exposes database settings from ENV. */
    db: {
        /** The FQDN of the SQL Server instance. */
        server: string | undefined;
        /** The name of the SQL Server database. */
        database: string | undefined;
        /** The user id for the SQL Server database. */
        user: string | undefined;
        /** The password for the SQL Server database. */
        password: string | undefined;
        /** SQL Server options.  */
        options: {
            /** Must be TRUE for SQL Server in Azure. */
            "encrypt": boolean;
        };
    };
};
export default settings;
