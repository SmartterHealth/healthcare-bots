import { ActivityHandler } from 'botbuilder';
export default class Icd2Bot extends ActivityHandler {
    private adapter;
    constructor(server: any);
    /** Sets the user ID for the current user in app insights. */
    private setUserId;
}
