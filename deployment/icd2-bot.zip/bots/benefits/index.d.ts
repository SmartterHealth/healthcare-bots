import { ActivityHandler } from 'botbuilder';
export default class BenefitsBot extends ActivityHandler {
    /** Reference to a BotFrameworkAdapter instance. */
    private adapter;
    /** Reference to a QnAMaker instance. */
    private qnaMaker;
    /**
     * Initializes the BenefitsBot instance.
     * @param server The HTTP server instance that is hosting the bot.
     */
    constructor(server: any);
    /**
     * Initialize the QNA maker instance.
     */
    private initQnAMaker;
    /**
     * Initialize the bot adapter instance.
     * @param server The HTTP server instance that is hosting the bot.
     */
    private initAdapter;
    /**
     * Handles an error that occurs during the bot conversation.
     * @param context Context object containing information cached for a single turn of conversation with a user.
     * @param error The error that occured during the bot conversation.
     */
    private handleError;
    /**
     * Handles whenever a new user is connected to the bot.
     * @param context Context object containing information cached for a single turn of conversation with a user.
     * @param next Callback Promise that lets the adapter know we are finished processing the user being added.
     */
    private handleOnMembersAdded;
    /**
     * Handles incoming messages from users to the bot.
     * @param context Context object containing information cached for a single turn of conversation with a user.
     * @param next Callback Promise that lets the adapter know we are finished processing the message.
     */
    private handleOnMessage;
}
