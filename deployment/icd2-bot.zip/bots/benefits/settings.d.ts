/**
 * IMPORTANT: Ensure that bot settings have unique prefix!
 */
declare const settings: {
    bot: {
        /** The ID of the bot registered in Azure. */
        MicrosoftAppId: string | undefined;
        /** The password/secret of the bot registered in Azure. */
        MicrosoftAppPassword: string | undefined;
        /** The ID of the QnA Maker Knowledge Base registered in Azure. You can get this value from https://www.qnamaker.ai/Home/MyServices */
        QnAKnowledgebaseId: string | undefined;
        /** The password/secret needed to connect to your QnA Maker Knowledge Base. You can get this in the Azure Portal. */
        QnAEndpointKey: string | undefined;
        /** The host name of the QnA Maker Knowledge Base registered in Azure. You can get this value from https://www.qnamaker.ai/Home/MyServices */
        QnAEndpointHostName: string | undefined;
    };
};
export default settings;
