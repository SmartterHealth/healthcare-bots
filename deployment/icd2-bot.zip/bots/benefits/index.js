"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Import required bot services.
// See https://aka.ms/bot-services to learn more about the different parts of a bot.
const botbuilder_1 = require("botbuilder");
const botbuilder_ai_1 = require("botbuilder-ai");
const assert_1 = require("../icd2/assert");
const settings_1 = require("./settings");
class BenefitsBot extends botbuilder_1.ActivityHandler {
    /**
     * Initializes the BenefitsBot instance.
     * @param server The HTTP server instance that is hosting the bot.
     */
    constructor(server) {
        super();
        this.initAdapter(server);
        this.initQnAMaker();
        // Setup event handlers for the bot.
        this.onMessage((context, next) => this.handleOnMessage(context, next));
        this.onMembersAdded((context, next) => this.handleOnMembersAdded(context, next));
    }
    /**
     * Initialize the QNA maker instance.
     */
    initQnAMaker() {
        const { QnAKnowledgebaseId, QnAEndpointKey, QnAEndpointHostName } = settings_1.default.bot;
        assert_1.Assert.isNotNullOrBlank(QnAKnowledgebaseId, 'env.QnAKnowledgebaseId');
        assert_1.Assert.isNotNullOrBlank(QnAEndpointKey, 'env.QnAEndpointKey');
        assert_1.Assert.isNotNullOrBlank(QnAEndpointHostName, 'env.QnAEndpointHostName');
        this.qnaMaker = new botbuilder_ai_1.QnAMaker({
            knowledgeBaseId: QnAKnowledgebaseId,
            endpointKey: QnAEndpointKey,
            host: QnAEndpointHostName,
        });
    }
    /**
     * Initialize the bot adapter instance.
     * @param server The HTTP server instance that is hosting the bot.
     */
    initAdapter(server) {
        const { MicrosoftAppId, MicrosoftAppPassword } = settings_1.default.bot;
        assert_1.Assert.isNotNullOrBlank(MicrosoftAppId, 'env.MicrosoftAppId');
        assert_1.Assert.isNotNullOrBlank(MicrosoftAppPassword, 'env.MicrosoftAppPassword');
        this.adapter = new botbuilder_1.BotFrameworkAdapter({
            appId: settings_1.default.bot.MicrosoftAppId,
            appPassword: settings_1.default.bot.MicrosoftAppPassword,
        });
        // tslint:disable-next-line: align
        server.post('/api/benefits/messages', (req, res) => {
            this.adapter.processActivity(req, res, async (context) => {
                // Route to main dialog.
                await this.run(context);
            });
        });
        // Catch-all for errors.
        // tslint:disable-next-line: align
        this.adapter.onTurnError = async (context, error) => this.handleError(context, error);
    }
    /**
     * Handles an error that occurs during the bot conversation.
     * @param context Context object containing information cached for a single turn of conversation with a user.
     * @param error The error that occured during the bot conversation.
     */
    async handleError(context, error) {
        // This check writes out errors to console log .vs. app insights.
        console.error(`\n [onTurnError]: ${(error)}. ${error.stack}`);
        if (process.env.NODE_ENV === 'DEVELOPMENT') {
            await context.sendActivity(`ERROR: ${error}\n${error.stack}`);
        }
        else {
            await context.sendActivity(`Apologies, but Something went wrong. Please contact your system administrator.`);
        }
    }
    /**
     * Handles whenever a new user is connected to the bot.
     * @param context Context object containing information cached for a single turn of conversation with a user.
     * @param next Callback Promise that lets the adapter know we are finished processing the user being added.
     */
    async handleOnMembersAdded(context, next) {
        const membersAdded = context.activity.membersAdded;
        if (membersAdded != null) {
            for (const member of membersAdded) {
                if (member.id !== context.activity.recipient.id) {
                    await context.sendActivity('Benefits Bot: Hello and welcome!');
                    console.log(this.qnaMaker);
                }
            }
        }
        // By calling next() you ensure that the next BotHandler is run.
        await next();
    }
    /**
     * Handles incoming messages from users to the bot.
     * @param context Context object containing information cached for a single turn of conversation with a user.
     * @param next Callback Promise that lets the adapter know we are finished processing the message.
     */
    async handleOnMessage(context, next) {
        console.log('Calling QnA Maker');
        const qnaResults = await this.qnaMaker.getAnswers(context);
        // If an answer was received from QnA Maker, send the answer back to the user.
        if (qnaResults[0]) {
            await context.sendActivity(qnaResults[0].answer);
            // If no answers were returned from QnA Maker, reply with help.
        }
        else {
            await context.sendActivity('No QnA Maker answers were found.');
        }
        // By calling next() you ensure that the next BotHandler is run.
        await next();
    }
}
exports.default = BenefitsBot;
//# sourceMappingURL=index.js.map